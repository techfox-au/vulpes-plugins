import { h, badge, fmt, empty, errorMessage, icon, panelNote, modal } from '../ui.js?v=shell119';
import { requireUserDataKey } from '../data-key.js?v=shell407';

let status = null;
let shareTimer = null;
let cveTimer = null;
let cryptoReady = null;
let keyPrompted = false;
let pendingFocus = '';
let focusScroll = false;
let focusNote = '';
let generation = 0;

export async function mount(el, ctx) {
  const gen = ++generation;
  let ownedTimer = null;
  let ownedCveTimer = null;
  const leave = () => {
    if (ownedTimer && shareTimer === ownedTimer) {
      clearInterval(ownedTimer);
      shareTimer = null;
    }
    if (ownedCveTimer && cveTimer === ownedCveTimer) {
      clearInterval(ownedCveTimer);
      cveTimer = null;
    }
    return gen;
  };
  status = null;
  ctx.setTitle(['Home']);
  const greeting = h('div', { class: 'page-header' },
    h('h1', null, 'Home'));
  const statusGrid = h('div', { class: 'grid cols-3' });
  const pluginsCard = h('div', { class: 'card' }, h('div', { class: 'card-header' }, h('h2', null, 'Plugins')), h('div', { class: 'muted' }, 'Loading…'));
  const cveCard = h('div', { class: 'card' }, cveHeader('Top CVEs', 'https://radar.cloudflare.com/zero-wire/cves'), h('div', { class: 'muted' }, 'Loading…'));
  const highCard = h('div', { class: 'card' }, cveHeader('High CVEs', 'https://radar.cloudflare.com/zero-wire/cves?severity=HIGH'), h('div', { class: 'muted' }, 'Loading…'));
  const alertsCard = h('div', { class: 'card' }, h('div', { class: 'card-header' }, h('h2', null, 'Recent alerts'), ctx.hasRole('Admin', 'Analyst') ? h('a', { class: 'btn sm', href: '/alerts' }, 'All alerts') : null), h('div', { class: 'muted' }, 'Loading…'));
  const sharesCard = h('div', { class: 'card share-panel', hidden: true });
  el.append(greeting, statusGrid, h('div', { class: 'grid cols-2' }, pluginsCard, alertsCard), h('div', { class: 'grid cols-2' }, cveCard, highCard), sharesCard);
  await renderCves(ctx, cveCard, highCard);
  if (gen !== generation) return leave();
  cveTimer = ownedCveTimer = setInterval(() => {
    if (gen !== generation) {
      if (cveTimer === ownedCveTimer) {
        clearInterval(ownedCveTimer);
        cveTimer = null;
      }
      return;
    }
    if (document.hidden) return;
    renderCves(ctx, cveCard, highCard, true);
  }, 30 * 60 * 1000);

  try {
    const nextStatus = await ctx.api.get('/api/status');
    if (gen !== generation) return leave();
    status = nextStatus;
    statusGrid.append(
      kpi('Search backend', status.elasticsearch?.enabled ? (status.elasticsearch.healthy ? 'Healthy' : 'Unreachable') : 'Not configured', status.elasticsearch?.enabled ? (status.elasticsearch.healthy ? 'success' : 'danger') : 'warning', esDetail(status.elasticsearch)),
      kpi('Alert rules', String(status.alerts?.enabledRules ?? 0), '', `${fmt.number(status.alerts?.alertsLast24h ?? 0)} alerts in 24h`),
      kpi('Notifications', status.notifications?.smtpConfigured ? 'Email ready' : 'Email not set', status.notifications?.smtpConfigured ? 'success' : 'warning', status.notifications?.pending ? `${status.notifications.pending} pending` : ''),
    );
  } catch (err) {
    if (gen !== generation) return leave();
    statusGrid.append(h('div', { class: 'alert danger' }, errorMessage(err)));
  }

  try {
    const pluginsPromise = ctx.api.get('/api/plugins');
    const updatesPromise = ctx.hasRole('Admin') ? ctx.api.get('/api/admin/plugins').catch(() => null) : Promise.resolve(null);
    const [plugins, adminPlugins] = await Promise.all([pluginsPromise, updatesPromise]);
    if (gen !== generation) return leave();
    const updateIds = new Set();
    for (const offer of adminPlugins?.available || []) {
      if (offer.action !== 'upgrade') continue;
      if (offer.pluginId) updateIds.add(offer.pluginId);
      for (const plugin of plugins) {
        if (offerMatches(plugin.id, offer.name)) updateIds.add(plugin.id);
      }
    }
    const loadedIds = new Set(plugins.map((m) => m.id));
    const failures = (status?.plugins?.failures || []).filter((f) => f.id && !loadedIds.has(f.id));
    const rows = [
      ...plugins.map((m) => h('div', { class: 'flex between' },
        h('div', null, h('div', null, h('strong', null, m.name), ' ', badge('v' + m.version), ' ', pluginHealth(m.id, updateIds))),
        h('a', { class: 'btn sm', href: `/p/${m.id}/${m.pages[0] || ''}` }, 'Open'))),
      ...failures.map((f) => h('div', { class: 'flex between' },
        h('div', null, h('div', null, h('strong', null, f.id), ' ', badge(f.unhealthy ? 'unhealthy' : 'failed', 'danger', true))))),
    ];
    const body = pluginsCard.lastChild;
    body.replaceWith(rows.length === 0 ? empty('No plugins installed.', 'plug') : h('div', { class: 'col' }, rows));
    if (plugins.some((plugin) => plugin.id === 'secret-sharing')) {
      pendingFocus = String(ctx.query?.focus || '').trim();
      focusScroll = !!pendingFocus;
      focusNote = '';
      await renderShares(ctx, sharesCard);
      if (gen !== generation) return leave();
      if (shareTimer) clearInterval(shareTimer);
      const timer = setInterval(() => {
        if (gen !== generation) {
          clearInterval(timer);
          if (shareTimer === timer) shareTimer = null;
          return;
        }
        if (document.hidden || document.querySelector('.modal')) return;
        renderShares(ctx, sharesCard, true);
      }, 5000);
      shareTimer = ownedTimer = timer;
    }
  } catch (err) {
    if (gen !== generation) return leave();
    pluginsCard.lastChild.replaceWith(h('div', { class: 'alert danger' }, errorMessage(err)));
  }

  if (gen !== generation) return leave();
  if (ctx.hasRole('Admin', 'Analyst')) {
    try {
      const alerts = await ctx.api.get('/api/alerts/instances?pageSize=8');
      if (gen !== generation) return leave();
      alertsCard.lastChild.replaceWith(alerts.items.length === 0 ? empty('No alerts yet.', 'bell')
        : h('div', { class: 'col' }, alerts.items.map((a) => h('div', { class: 'flex between' },
          h('div', { class: 'grow' }, h('div', { class: 'truncate' }, badge(a.severity, severityKind(a.severity)), ' ', a.summary), h('div', { class: 'small muted' }, `${a.ruleName} · ${fmt.relative(a.createdAt)}${a.count > 1 ? ` · ×${a.count}` : ''}`)),
          badge(a.status, a.status === 'new' ? 'primary' : '')))));
    } catch (err) {
      if (gen !== generation) return leave();
      alertsCard.lastChild.replaceWith(h('div', { class: 'alert danger' }, errorMessage(err)));
    }
  } else {
    alertsCard.lastChild.replaceWith(empty('No alerts.', 'bell'));
  }
  return gen;
}

export function unmount(gen) {
  if (gen !== generation) return;
  generation += 1;
  if (shareTimer) clearInterval(shareTimer);
  shareTimer = null;
  if (cveTimer) clearInterval(cveTimer);
  cveTimer = null;
  pendingFocus = '';
  focusScroll = false;
  focusNote = '';
  keyPrompted = false;
}

function offerMatches(pluginId, offerName) {
  const stem = String(offerName || '').replace(/\.7z$/i, '').toLowerCase().replace(/[._]/g, '-');
  const id = String(pluginId || '').toLowerCase();
  return stem === id || stem.endsWith('-' + id);
}

function applyFocus(card) {
  if (focusNote) panelNote(card, focusNote, 'warning');
  if (!pendingFocus) return;
  const item = card.querySelector('.share-item[data-id="' + CSS.escape(pendingFocus) + '"]');
  if (!item) {
    focusNote = 'That item is not on your dashboard (deleted, expired, or not yours).';
    panelNote(card, focusNote, 'warning');
    pendingFocus = '';
    focusScroll = false;
    return;
  }
  focusNote = '';
  item.classList.add('share-item-focus');
  if (focusScroll) {
    item.scrollIntoView({ block: 'center' });
    const id = pendingFocus;
    const focusGen = generation;
    focusScroll = false;
    setTimeout(() => { if (focusGen !== generation || pendingFocus !== id) return; pendingFocus = ''; }, 2400);
  }
}

function shareHeader(ctx) {
  const actions = [h('a', { class: 'btn sm', href: '/p/secret-sharing/send' }, 'Send secret')];
  if (ctx.hasRole('Admin', 'Analyst')) actions.push(h('a', { class: 'btn sm', href: '/p/secret-sharing/collect' }, 'Collect secret'));
  return h('div', { class: 'card-header' }, h('h2', null, 'Secret sharing'), h('div', { class: 'btn-group' }, actions));
}

async function renderShares(ctx, card, quiet) {
  const gen = generation;
  card.hidden = false;
  const canCollect = ctx.hasRole('Admin', 'Analyst');
  if (!quiet) card.replaceChildren(shareHeader(ctx), h('p', { class: 'muted' }, 'Loading…'));
  try {
    await ensureCrypto();
    if (gen !== generation) return;
    const data = await ctx.api.get('/api/plugins/secret-sharing/home');
    if (gen !== generation) return;
    const items = (data.items || []).filter((item) => canCollect || item.kind !== 'collect');
    if (gen === generation && !keyPrompted && !window.SecretUdk.loadUserDataKey(ctx.user?.id) && items.some((item) => item.encryptedLabel || item.privateNoteCiphertext || item.hasOwnerKey)) {
      try { await requireUserDataKey(); } catch { /* names stay locked until a later attempt */ }
      if (gen !== generation) return;
      keyPrompted = true;
    }
    if (gen !== generation) return;
    const rows = [];
    for (const item of items) rows.push(await shareItem(ctx, card, item));
    if (gen !== generation) return;
    const list = items.length === 0
      ? h('p', { class: 'muted share-empty' }, canCollect ? 'No sends or collects yet.' : 'No sends yet.')
      : h('div', { class: 'share-list' }, rows);
    const header = card.querySelector(':scope > .card-header') || shareHeader(ctx);
    card.replaceChildren(header, list);
    applyFocus(card);
  } catch (err) {
    if (gen !== generation) return;
    const note = h('div', { class: 'alert danger' }, errorMessage(err));
    if (quiet && card.querySelector('.share-list, .share-empty')) panelNote(card, errorMessage(err));
    else card.replaceChildren(shareHeader(ctx), note);
  }
}

async function shareItem(ctx, panel, item) {
  const collect = item.kind === 'collect';
  const noun = collect ? 'collect' : 'send';
  const shown = item.status === 'waiting' ? 'pending' : item.status;
  const title = await ownerText(item.encryptedLabel, ctx.user?.id);
  const note = item.privateNoteCiphertext ? await ownerText(item.privateNoteCiphertext, ctx.user?.id) : '';
  const canCollect = collect && item.hasOwnerKey && item.status === 'ready';
  const modeTitle = item.oneTime ? `This ${noun} can only be viewed once` : `This ${noun} can be accessed multiple times`;
  const meta = [
    chip(noun),
    chip(item.oneTime ? 'one-time' : 'multi', '', modeTitle),
  ];
  if (item.passwordProtected) meta.push(chip('Password', 'password', `This ${noun} is protected by a password`));
  if (item.ipRestricted) meta.push(chip('IP', 'ip', `This ${noun} is IP address restricted`));
  if (!item.oneTime) {
    const count = item.accessCount || 0;
    if (item.maxAccessCount != null && item.maxAccessCount !== '') meta.push(chip(`${count}/${item.maxAccessCount} opens`, 'access'));
    else if (count > 0) meta.push(chip(`${count} ${count === 1 ? 'open' : 'opens'}`, 'access'));
  }
  let when = '';
  try { when = new Date(item.expiresAt).toLocaleString(); } catch { when = String(item.expiresAt || ''); }
  meta.push(h('span', { class: 'share-expires' }, `Expires ${when}`));

  const article = h('article', { class: 'share-item' + (canCollect ? ' clickable' : ''), dataset: { id: item.id, kind: item.kind, status: item.status } });
  const actions = [];
  if (collect && item.hasOwnerKey && item.status !== 'consumed') {
    actions.push(h('button', {
      class: 'btn sm', type: 'button', disabled: !canCollect,
      title: collectTitle(item.status),
      onClick: (ev) => { ev.stopPropagation(); if (canCollect) openCollect(ctx, article, item); },
    }, 'Collect'));
  }
  if (collect && item.status === 'waiting') {
    actions.push(h('button', { class: 'btn sm', type: 'button', onClick: (ev) => { ev.stopPropagation(); copyUpload(panel, item); } }, 'Copy upload link'));
  }
  actions.push(h('button', { class: 'btn sm danger', type: 'button', onClick: (ev) => { ev.stopPropagation(); removeShare(ctx, panel, item); } }, 'Delete'));
  const parts = [
    h('div', { class: 'share-item-head' },
      h('div', { class: 'share-item-title' }, title == null ? '(unlock encryption to view name)' : title),
      h('div', { class: 'share-item-tags' }, chip(item.id, 'id', 'ID'), statusBadge(shown))),
    h('div', { class: 'share-meta' }, meta),
    item.privateNoteCiphertext ? h('div', { class: 'share-note' }, h('strong', null, 'Private note: '), note == null ? '(unlock encryption to view the note)' : note) : null,
    h('div', { class: 'share-actions' }, actions),
  ].filter(Boolean);
  article.append(...parts);
  if (canCollect) article.addEventListener('click', (ev) => { if (ev.target.closest('button, a')) return; openCollect(ctx, article, item); });
  return article;
}

function chip(text, className, tooltip) {
  const props = { class: 'share-chip' + (className ? ' ' + className : '') };
  if (tooltip) props['data-tooltip'] = tooltip;
  return h('span', props, className === 'id' ? h('span', null, text) : text);
}

function statusBadge(status) {
  const kind = status === 'active' || status === 'ready' ? 'success' : status === 'consumed' || status === 'expired' ? 'danger' : '';
  return h('span', { class: 'badge share-status ' + status + (kind ? ' ' + kind : '') }, status);
}

function collectTitle(status) {
  if (status === 'waiting') return 'Waiting for upload';
  if (status === 'consumed') return 'Already collected (will be removed when purged)';
  if (status === 'expired') return 'Expired (will be removed when purged)';
  if (status === 'ready') return 'Open collect page';
  return 'Not ready to collect';
}

async function ownerText(cipher, userId) {
  if (!cipher) return '';
  const udk = window.SecretUdk && window.SecretUdk.loadUserDataKey(userId);
  if (!udk) return null;
  try {
    const bytes = await window.SecretUdk.decryptWithUserDataKey(cipher, udk);
    const text = new TextDecoder().decode(bytes);
    bytes.fill(0);
    return text;
  } catch {
    return null;
  }
}

function ensureCrypto() {
  if (!cryptoReady) {
    cryptoReady = loadScript('/assets/js/crypto/vulpes-crypto.js?v=crypto3')
      .then(() => window.VulpesCrypto.ready())
      .then(() => loadScript('/assets/js/udk.js?v=udk6'))
      .then(() => window.SecretUdk.ready())
      .catch((err) => {
        cryptoReady = null;
        throw err;
      });
  }
  return cryptoReady;
}

async function copyUpload(panel, item) {
  if (!item.publicKey) {
    panelNote(panel, 'This collect has no public key to put in the upload link.');
    return;
  }
  const upload = `${location.origin}/upload?id=${encodeURIComponent(item.id)}#pk=${encodeURIComponent(item.publicKey)}`;
  try {
    await navigator.clipboard.writeText(upload);
    panelNote(panel, 'Upload link copied.', 'success');
  } catch {
    panelNote(panel, 'Could not copy; select and copy manually.');
  }
}

async function openCollect(ctx, card, item) {
  const note = card.querySelector('.share-error') || h('div', { class: 'alert danger share-error' });
  note.textContent = '';
  try {
    await loadScript('/assets/js/crypto/vulpes-crypto.js?v=crypto3');
    await window.VulpesCrypto.ready();
    await loadScript('/assets/js/udk.js?v=udk6');
    await window.SecretUdk.ready();
    const udk = await requireUserDataKey();
    const pack = await ctx.api.get(`/api/plugins/secret-sharing/collects/${encodeURIComponent(item.id)}/owner-key`);
    const plain = await window.SecretUdk.decryptWithUserDataKey(pack.ownerPrivateKeyProtected, udk);
    const fragment = item.passwordProtected
      ? window.SenditCrypto.buildPasswordProtectedFragment(new TextDecoder().decode(plain))
      : plain.length === 32
        ? window.SenditCrypto.buildFragment(plain)
        : '#sk=' + window.SenditCrypto.b64urlEncode(plain);
    plain.fill(0);
    location.assign(`${location.origin}/collect?id=${encodeURIComponent(item.id)}${fragment}`);
  } catch (err) {
    note.textContent = err.message || 'Could not open the collect.';
    card.append(note);
  }
}

function loadScript(src) {
  if (document.querySelector(`script[src="${src}"]`)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => resolve();
    s.onerror = () => {
      s.remove();
      reject(new Error('Could not load encryption.'));
    };
    document.head.append(s);
  });
}

async function removeShare(ctx, card, item) {
  if (!(await modal.confirm('Delete item', 'Delete this item? This cannot be undone.', { danger: true, confirmLabel: 'Delete' }))) return;
  try {
    await ctx.api.delete(`/api/plugins/secret-sharing/${item.kind === 'collect' ? 'collects' : 'sends'}/${encodeURIComponent(item.id)}`);
    await renderShares(ctx, card, true);
  } catch (err) {
    panelNote(card, err.message || 'Could not delete the item.');
  }
}

function pluginHealth(id, updateIds) {
  if (updateIds.has(id)) return badge('update', 'warning', true);
  return badge('healthy', 'success', true);
}

function esDetail(es) {
  if (!es?.enabled || es.healthy) return '';
  return es.error || '';
}

function cveHeader(title, href) {
  return h('div', { class: 'card-header' },
    h('h2', null, title),
    h('a', { class: 'btn sm', href: href, target: '_blank', rel: 'noopener noreferrer' }, 'Cloudflare Radar'));
}

function cveRows(items, emptyText) {
  return items.length === 0 ? empty(emptyText, 'shield')
    : h('div', { class: 'col' }, items.map((item) => {
      const severity = item.severity || 'Not scored';
      return h('a', {
        class: 'flex between cve-row',
        href: item.url,
        target: '_blank',
        rel: 'noopener noreferrer',
      },
        h('div', { class: 'grow' },
          h('div', { class: 'cve-copy' }, h('strong', null, item.id), ' ', badge(severity, severityKind(severity.toLowerCase())), item.score != null ? ' ' + item.score : ''),
          h('div', { class: 'small muted cve-copy' }, item.title || item.summary || '')),
        h('div', { class: 'small muted cve-when' }, fmt.relative(item.published)));
    }));
}

async function renderCves(ctx, card, highCard, quiet) {
  const gen = generation;
  const latestHeader = () => cveHeader('Top CVEs', 'https://radar.cloudflare.com/zero-wire/cves');
  const highHeader = () => cveHeader('High CVEs', 'https://radar.cloudflare.com/zero-wire/cves?severity=HIGH');
  if (!quiet) {
    card.replaceChildren(latestHeader(), h('div', { class: 'muted' }, 'Loading…'));
    highCard.replaceChildren(highHeader(), h('div', { class: 'muted' }, 'Loading…'));
  }
  try {
    const data = await ctx.api.get('/api/radar/cves');
    if (gen !== generation) return;
    card.replaceChildren(latestHeader(), cveRows(data.items || [], 'No CVEs published.'));
    highCard.replaceChildren(highHeader(), cveRows(data.high || [], 'No High CVEs published.'));
  } catch (err) {
    if (gen !== generation) return;
    const alert = h('div', { class: 'alert danger' }, errorMessage(err));
    card.replaceChildren(latestHeader(), alert);
    highCard.replaceChildren(highHeader(), alert.cloneNode(true));
  }
}

function kpi(label, value, kind, delta) {
  return h('div', { class: 'card kpi ' + (kind || '') }, h('div', { class: 'label' }, label), h('div', { class: 'value' }, value), h('div', { class: 'delta' }, delta || ''));
}

export function severityKind(sev) {
  return { critical: 'danger', high: 'danger', medium: 'warning', low: 'info', informational: '' }[sev] || '';
}
